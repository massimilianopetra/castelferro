'use client';
import { memo } from 'react';
import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Button, ButtonGroup, Snackbar, TextField, Modal, Box, Typography, IconButton,FormControlLabel, Switch  } from '@mui/material';
import StarsIcon from '@mui/icons-material/Stars';
import CircularProgress from '@mui/material/CircularProgress';
import Filter1Icon from '@mui/icons-material/Filter1';
 
import type { DbConsumazioni, DbFiera, DbConti, DbLog } from '@/app/lib/definitions';
import {
    getConsumazioni,
    sendConsumazioni,
    getConto,
    apriConto,
    getCamerieri,
    writeLog,
    getGiornoSagra,
    getLastLog,
    getMenu,
    getTickets,
    salvaComandaCompleta,
    listConsumazioni
} from '@/app/lib/actions';

import TabellaCucina from '@/app/ui/dashboard/TabellaCucina';

const styleModal = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '90vw',
    height: '90vh',
    maxWidth: '1200px',
    maxHeight: '90vh',
    bgcolor: 'background.paper',
    border: '4px solid #1976d2',
    boxShadow: 24,
    p: 4,
    borderRadius: '15px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between'
};

export default function Cucina({ nomeCucina: nomeOriginale }: { nomeCucina: string }) {
  // Trasformiamo la prop in una variabile locale "pulita" (secondo me non serve, ma lo lascio per sicurezza)
  const nomeCucina = nomeOriginale.trim().endsWith('E') 
    ? nomeOriginale.trim().slice(0, -1) 
    : nomeOriginale;


    const { data: session } = useSession();
    const [phase, setPhase] = useState('iniziale');
    const [isNewConto, setIsNewConto] = useState(false); // <-- Stato per tracciare se il conto è nuovo o pre-esistente
    const [lastLog, setLastLog] = useState<DbLog[]>([]);
    const [products, setProducts] = useState<DbConsumazioni[]>([]);
    const [iniProducts, setIniProducts] = useState<DbConsumazioni[]>([]);
    const [numero, setNumero] = useState<number | string>('');
    const [numeroFoglietto, setNumeroFoglietto] = useState<number | string>('');
    const [sagra, setSagra] = useState<DbFiera>({ id: 1, giornata: 1, stato: 'CHIUSA' });
    const [conto, setConto] = useState<DbConti>(); // <-- RIPRISTINATO QUI!
    const [isSagraLoading, setIsSagraLoading] = useState(true); // <-- STATO AGGIUNTO PER EVITARE IL LAMPO INIZIALE
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [openPopup, setOpenPopup] = useState(false);
    const [showAlternateView, setShowAlternateView] = useState(false);
    const [chiamataunicaDB, setChiamataunicaDB] = useState(false);
    const [nuovaquantitaValue, setQuantitaValue] = useState('');
    const [idmodificaquantitaValue, setIdModQuantita] = useState(1);
    const [piattomodificaquantitaValue, setPiattoModQuantita] = useState("non definito");
    const [copertiInAttesa, setCopertiInAttesa] = useState(0);
    const [menuPrevisionale, setMenuPrevisionale] = useState<any[]>([]);
    const [dettaglioCoperti, setDettaglioCoperti] = useState({ seduti: 0, nonseduti_incoda: 0, serviti: 0 });
    const [snackbarMessage, setSnackbarMessage] = useState('');

// 3. Logica autorizzazione
    const authorizedNames = [
    "BevandeE", 
    "AntipastiE", 
    "PrimiE", 
    "SecondiE", 
    "DolciE", 
    "BirreE", // Qui hai "birree"
    "SuperUser"
    ];
    const isAuthorizedUser = authorizedNames.includes(session?.user?.name ?? "");


    useEffect(() => {
        const fetchData = async () => {
            try {
                const gg = await getGiornoSagra();
                if (gg) {
                    setSagra(gg);
                }
            } catch (error) {
                console.error("Errore nel recupero dello stato della sagra - cucine:", error);
            } finally {
                setIsSagraLoading(false); // <-- STOP AL CARICAMENTO DELLA GIORNATA
            }
        };
        fetchData();
    }, []);

    const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) =>
        setNumero(event.target.value);
    const handleClose = () => setOpenSnackbar(false);
    const handleClosePopup = () => setOpenPopup(false);
    const handleToggleView = () => setShowAlternateView(prev => !prev);
    const handlechiamataunicaDB = () => setChiamataunicaDB(prev => !prev);
    const handleButtonClickCaricaConto1 = () => carica(1);

    /* ------------------------------CARICAMENTO CONTO------------------------------ */
    async function carica(num: number) {
        if (isNaN(num) || num < 1 || num > 8999) {
            // Decidiamo qui il messaggio usando direttamente il parametro 'num' passato alla funzione
            if (num > 9999) {
                setSnackbarMessage("3. Inserisci un numero foglietto valido (minore di 8999)");
            } else {
                setSnackbarMessage("4 .Hai inserito un numero riservato asporto (compreso tra 9000 e 9999)");
            }
            setOpenSnackbar(true);
            return;
        }
        setPhase('caricamento');

        const [c, cc] = await Promise.all([
            getConsumazioni(nomeCucina, num, sagra.giornata, 'MUST_BE_AVAILABLE'),
            getConto(num, sagra.giornata)
        ]);

        if (c) {
            setProducts(c);
            setIniProducts(c);
        }
        setNumeroFoglietto(num);

        if (cc) {
            setConto(cc);
            setIsNewConto(false); // Il conto esiste già sul database
            if (['CHIUSO', 'STAMPATO', 'CHIUSOPOS', 'CHIUSOALTRO'].includes(cc.stato)) {
                setPhase('bloccato');
                return;
            }
            if (cc.cameriere === 'Sconosciuto') {
                setPhase('sconosciuto');
                return;
            }

            await writeLog(num, sagra.giornata, nomeCucina, '', 'OPEN', '');
            const logs = await getLastLog(sagra.giornata, nomeCucina);
            if (logs) setLastLog(logs);

            setPhase('caricato');
        } else {
            const cameriere = await getCamerieri(num);
            if (!cameriere || cameriere === 'Sconosciuto') {
                setPhase('sconosciuto');
                return;
            }

            setIsNewConto(true); // È un conto nuovo, non ancora registrato sul DB
            setConto({
                foglietto: num,
                giornata: sagra.giornata,
                cameriere: cameriere,
                stato: 'APERTO'
            } as any);

            setPhase('caricato');
        }
    }

    const handleButtonClickCarica = () => {
        carica(Number(numero));
        setNumero('');
    };

    const handleButtonClickAnnulla = () => {
        setPhase('iniziale');
        setProducts([]);
        setIniProducts([]);
    };

    const caricaStatistiche = async () => {
        // Se le statistiche sono disabilitate globalmente, blocca l'esecuzione e le query sul database
        if (!isAuthorizedUser) {
            setSnackbarMessage("Statistiche disattivate temporaneamente per alleggerire il carico del server.");
            setOpenSnackbar(true);
            return;
        }
        
        try {
            const [
                ticketNonSedutiRows,
                ticketSedutiRows,
                consumazioniCoperti,
                fullMenu
            ] = await Promise.all([
                getTickets('non-seduti'),
                getTickets('seduti'),
                listConsumazioni(1, sagra.giornata),
                getMenu()
            ]);
            const nonseduti_incoda = ticketNonSedutiRows?.reduce((acc, curr) => acc + curr.numpersone, 0) || 0;
            const seduti = ticketSedutiRows?.reduce((acc, curr) => acc + curr.numpersone, 0) || 0;
            const serviti = consumazioniCoperti?.reduce((acc, curr) => acc + curr.quantita, 0) || 0;
            const totale = (seduti + nonseduti_incoda) - serviti;

            setDettaglioCoperti({ seduti, nonseduti_incoda, serviti });
            setCopertiInAttesa(Math.max(0, totale));

            if (fullMenu) {
                const filtrato = fullMenu.filter(m => m.cucina === nomeCucina);
                setMenuPrevisionale(filtrato);
            }

            setOpenPopup(true);
        } catch (error) {
            console.error("Errore durante il caricamento delle statistiche della cucina:", error);
        }
    };

    /* ------------------------------INVIO CONSUMAZIONI------------------------------ */
    const handleButtonClickInvia = async () => {
        //   if (chiamataunicaDB) {
        //             setSnackbarMessage("handleButtonClickInviaNew chiamata unica DB");
        //  setOpenSnackbar(true);
        //      await handleButtonClickInviaNew();
        //  } else {
        // setSnackbarMessage("handleButtonClickInviaOld chiamate standard");
        // setOpenSnackbar(true);
        await handleButtonClickInviaOld();
        //  }
    };

/*
    const handleButtonClickInviaNew = async () => {
        const haPortateValide = products.some(item => item.quantita > 0);

        if (!haPortateValide && isNewConto) {
            setPhase('iniziale');
            setProducts([]);
            setIniProducts([]);
            return;
        }

        setPhase('invio_in_corso');

        try {
            const numFoglietto = Number(numeroFoglietto);

            // 1. Generiamo l'array dei messaggi di LOG in modo sincrono sul client
            const logMessaggi = products
                .map(item => {
                    const orig = iniProducts.find(o => o.id_piatto === item.id_piatto);
                    const origQuantita = orig ? orig.quantita : 0;
                    if (item.quantita === origQuantita) return null;

                    return item.quantita > origQuantita
                        ? `Aggiunti: ${item.quantita - origQuantita} ${item.piatto}`
                        : `Eliminati: ${origQuantita - item.quantita} ${item.piatto}`;
                })
                .filter((msg): msg is string => msg !== null);

            // 2. Chiamata UNICA al Database
            const response = await salvaComandaCompleta(
                numFoglietto,
                sagra.giornata,
                conto?.cameriere || 'Sconosciuto',
                nomeCucina,
                isNewConto,
                products,
                logMessaggi
            );

            if (response.success === false && response.error === 'DUPLICATE_CONTO') {
                setSnackbarMessage("ATTENZIONE: Un'altra cucina ha appena aperto questo conto. Operazione bloccata per evitare duplicati.");
                setOpenSnackbar(true);
                setPhase('caricato');
                return;
            }

            if (isNewConto) setIsNewConto(false);
            if (response.logs) setLastLog(response.logs);

            setPhase('inviato');
            setProducts([]);
            setIniProducts([]);

        } catch (error) {
            console.error("Errore nell'invio:", error);
            setSnackbarMessage("Errore durante il salvataggio.");
            setOpenSnackbar(true);
            setPhase('caricato');
        }
    };
*/
    const handleButtonClickInviaOld = async () => {
        const haPortateValide = products.some(item => item.quantita > 0);

        // NUOVO CONTROLLO: Se il conto è NUOVO (isNewConto === true) e non ha piatti (> 0),
        // allora usciamo subito senza toccare il DB, pulendo solo la schermata.
        if (!haPortateValide && isNewConto) {
            setPhase('iniziale');
            setProducts([]);
            setIniProducts([]);
            return;
        }

        // Impostiamo la fase di invio in corso per mostrare lo spinner
        setPhase('invio_in_corso');

    try {
        const numFoglietto = Number(numeroFoglietto);

        // 1. SCARICHIAMO I DATI FRESCHI DAL DB ADESSO
        const [consumazioniFresh, contoFresh] = await Promise.all([
            getConsumazioni(nomeCucina, numFoglietto, sagra.giornata, 'MUST_BE_AVAILABLE'),
            getConto(numFoglietto, sagra.giornata)
        ]);

        if (isNewConto && contoFresh) {
            // Se nel frattempo un'altra cucina ha già aperto il conto
            setSnackbarMessage("ATTENZIONE: Un'altra cucina ha appena aperto questo conto. Operazione bloccata per evitare duplicati.");
            setOpenSnackbar(true);
            setPhase('caricato');
            return;
        }

        if (isNewConto) {
            // OTTIMIZZAZIONE 1: Lanciamo in parallelo l'apertura del conto e il log iniziale
            await Promise.all([
                apriConto(numFoglietto, sagra.giornata, conto?.cameriere || 'Sconosciuto'),
                writeLog(numFoglietto, sagra.giornata, nomeCucina, '', 'START', '')
            ]);
            setIsNewConto(false);
        }

        // 2. UNIAMO LE QUANTITÀ DELLO SCHERMO CON GLI ID DEL DATABASE APPENA SCARICATI
        // `products` contiene le quantità correnti decise dall'utente in questa cucina
        const datiDaInviare: DbConsumazioni[] = products.map(itemSchermo => {
            // Cerchiamo se questo piatto esiste già sul database (magari inserito dall'altra cucina, es. Pane e Coperto)
            const riscontroDb = consumazioniFresh?.find(dbItem => dbItem.id_piatto === itemSchermo.id_piatto);
            
            return {
                ...itemSchermo,
                id: riscontroDb ? riscontroDb.id : -1, // Se esiste sul DB prende il suo ID reale, altrimenti resta -1
                // Se la riga esiste sul DB ma appartiene a un'ALTRA cucina (es. Pane e Coperto), e noi non l'abbiamo toccata (quantità sullo schermo pari a 0 o al valore iniziale originario), 
                // manteniamo la quantità del DB per evitare di azzerare il lavoro altrui
                quantita: (itemSchermo.cucina !== nomeCucina && itemSchermo.quantita === 0 && riscontroDb) 
                    ? riscontroDb.quantita 
                    : itemSchermo.quantita
            };
        });

        // 3. Generiamo i log usando i vecchi iniProducts
        const logPromises = products
            .map(item => {
                const orig = iniProducts.find(o => o.id_piatto === item.id_piatto);
                const origQuantita = orig ? orig.quantita : 0;
                if (item.quantita === origQuantita) return null;

                const message = item.quantita > origQuantita
                    ? `Aggiunti: ${item.quantita - origQuantita} ${item.piatto}`
                    : `Eliminati: ${origQuantita - item.quantita} ${item.piatto}`;

                return writeLog(item.id_comanda, sagra.giornata, nomeCucina, '', 'UPDATE', message);
            })
            .filter((p): p is Promise<any> => p !== null);

        // 4. INVIAMO E ATTENDIAMO REALMENTE IL COMPLETAMENTO
        // Inviamo `datiDaInviare` che contiene gli ID reali corretti aggiornati!
        await Promise.all([
            ...logPromises,
            sendConsumazioni(datiDaInviare) 
        ]);

        // OTTIMIZZAZIONE 2: Lanciamo in parallelo l'aggiornamento del totale e il fetch degli ultimi log
        // Entrambi hanno bisogno che le chiamate precedenti siano finite, ma sono indipendenti tra di loro.
        const [logs] = await Promise.all([
       // const [, logs] = await Promise.all([
            //   updateTotaleConto(numFoglietto, sagra.giornata),
            getLastLog(sagra.giornata, nomeCucina)
        ]);

        if (logs) setLastLog(logs);

        setPhase('inviato');
        setProducts([]);
        setIniProducts([]);
    } catch (error) {
        console.error("Errore nell'invio:", error);
        setSnackbarMessage("Errore durante il salvataggio.");
        setOpenSnackbar(true);
        setPhase('caricato');
    }
};

    /* ------------------------------       MODIFICA QUANTITA'    ------------------------------ */
    const updateQuantity = useCallback((id: number, delta: number) => {
        setProducts(prevProducts => prevProducts.map(item =>
            item.id_piatto === id
                ? { ...item, quantita: Math.max(0, item.quantita + delta) }
                : item
        ));
    }, []);

    const handleAdd = useCallback((id: number) => updateQuantity(id, 1), [updateQuantity]);
    const handleAdd10 = useCallback((id: number) => updateQuantity(id, 10), [updateQuantity]);
    const handleRemove = useCallback((id: number) => updateQuantity(id, -1), [updateQuantity]);

    const handleSet = useCallback((id: number) => {
        setProducts(prevProducts => {
            const item = prevProducts.find(p => p.id_piatto === id);
            if (!item) return prevProducts;
            setIdModQuantita(id);
            setPiattoModQuantita(item.piatto);
            setQuantitaValue(String(item.quantita));
            setPhase('modificaquantita');
            return prevProducts;
        });
    }, []);

    const handleModificaQuantita = () => {
        setProducts(products.map(item =>
            item.id_piatto === idmodificaquantitaValue
                ? { ...item, quantita: Number(nuovaquantitaValue) }
                : item
        ));
        setPhase('caricato');
    };

    const handleAnnulla = () => setPhase('caricato');

    const user = session?.user?.name?.trim().endsWith('E') 
  ? session.user.name.trim().slice(0, -1) 
  : session?.user?.name?.trim() || "";

    const renderPhaseContent = () => {
        if (phase === 'iniziale')
            return (
                <div className='text-center'>
                    <p className="text-5xl py-4">Caricare un numero foglietto!!</p>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleToggleView}
                        sx={{ mt: 3, borderRadius: '9999px' }}
                    >
                        {showAlternateView
                            ? 'Disattiva Visualizzazione Elementare'
                            : 'Attiva Visualizzazione Elementare'}
                    </Button>
 
                </div>
            );

        if (phase === 'caricamento')
            return (
                <div className='text-center'>
                    <p className="text-5xl py-4">Cucina</p>
                    <CircularProgress size="9rem" />
                    <p className="text-5xl py-4">Caricamento in corso ...</p>
                </div>
            );

        if (phase === 'invio_in_corso')
            return (
                <div className='text-center'>
                    <p className="text-5xl py-4">Cucina</p>
                    <CircularProgress size="9rem" />
                    <p className="text-5xl py-4">Invio dati in corso ...</p>
                </div>
            );

        if (phase === 'caricato')
            return (
                <TabellaCucina
                    item={products}
                    onAdd10={handleAdd10}
                    onAdd={handleAdd}
                    onRemove={handleRemove}
                    onSet={handleSet}
                    showDetailedControls={showAlternateView}
                />
            );

        if (phase === 'inviato')
            return (
                <div className='text-center'>
                    <p className="text-5xl py-4">Inviato con successo!!</p>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleToggleView}
                        sx={{ mt: 3, borderRadius: '9999px' }}
                    >
                        {showAlternateView
                            ? 'Disattiva Visualizzazione Elementare'
                            : 'Attiva Visualizzazione Elementare'}
                    </Button>

                </div>
            );

        if (phase === 'sconosciuto')
            return (
                <div className='text-center'>
                    <p className="text-5xl py-4">
                        Conto non valido: cameriere sconosciuto!
                    </p>
                </div>
            );

        if (phase === 'bloccato')
            return (
                <div className='text-center'>
                    <p className="text-5xl py-4">
                        Conto non valido: bloccato dalle casse!
                    </p>
                </div>
            );

        if (phase === 'modificaquantita')
            return (
                <div className="flex items-center justify-center min-h-screen">
                    <div className="w-[600px] p-4 space-y-4 border-4 border-blue-600 shadow-2xl bg-blue-200 rounded">
                        <p className="text-xl">
                            Per il conto numero:
                            <span className="font-extrabold text-blue-800">
                                {numeroFoglietto}
                            </span>
                            inserisci la quantità per:
                            <span className="font-extrabold text-blue-800">
                                {piattomodificaquantitaValue}
                            </span>
                        </p>
                        <TextField
                            label="Modifica quantità"
                            variant="outlined"
                            value={nuovaquantitaValue}
                            onChange={(e) => setQuantitaValue(e.target.value)}
                            type="number"
                            fullWidth
                        />
                        <div className="flex justify-center space-x-4">
                            <Button variant="contained" onClick={handleModificaQuantita}>
                                Salva
                            </Button>
                            <Button variant="contained" onClick={handleAnnulla}>
                                Annulla
                            </Button>
                        </div>
                    </div>
                </div>
            );
        return null;
    };

    // --- SCHERMATA DI CARICAMENTO INIZIALE STATO SAGRA ---
    if (isSagraLoading) {
        return (
            <main>
                <Box sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    height: '80vh',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
                    <CircularProgress size="6rem" />
                    <Typography variant="h5" sx={{ mt: 2, fontWeight: 'bold', color: 'text.secondary' }}>
                        Verifica stato apertura giornata sagra (CUCINE)
                    </Typography>
                </Box>
            </main>
        );
    }

    if ((user || "" == nomeCucina) || (user == "SuperUser")) {
        if (sagra.stato == 'CHIUSA') {
            return (
                <main>
                    <div className="flex flex-wrap flex-col">
                        <div className='text-center '>
                            <div className="p-4 mb-4 text-xl text-yellow-800 rounded-lg bg-yellow-50" role="alert">
                                <span className="text-xl font-semibold">Attenzione</span> |Cucina| La giornata non è stata ancora aperta!
                            </div>
                        </div>
                    </div>
                </main>
            );
        } else {
            return (
                <main>
                    <div className="container_cucine">
                        {phase !== 'caricato' && phase !== 'modificaquantita' && phase !== 'invio_in_corso' ? (
                            <header className="header_cucine_sup">
                                <div className="p-30 font-extralight border-4 border-blue-600 shadow-2xl bg-blue-200 text-end rounded-full" style={{ borderRadius: '9999px' }}>
                                    <ul className="flex" style={{ borderRadius: '9999px' }}>
                                        <li className="flex-1 mr-2font-bold py-2 ">
                                            <a className="text-center block text-blue-700 font-extraligh text-2xl md:text-5xl">
                                                {nomeCucina}
                                            </a>
                                            <div className="text-xs text-center text-blue-700 ">SAGRA:
                                                <span className="text-xs text-center text-blue-800 font-semibold">{sagra.stato}&nbsp;{(sagra.stato == 'CHIUSA') ? "" : "(" + sagra.giornata + ")"}</span>
                                            </div>
                                        </li>
                                        <li className="text-right flex-1 mr-2 text-5xl  text-white font-bold py-4 rounded-full " style={{ borderRadius: '9999px' }}>
                                            <div className='text-center text-emerald-600'>
                                                <TextField
                                                    autoFocus
                                                    className="p-2"
                                                    label="Numero Foglietto"
                                                    variant="outlined"
                                                    value={numero}
                                                    onChange={handleInputChange}
                                                    style={{ borderRadius: '9999px' }}
                                                    sx={{
                                                        input: {
                                                            textAlign: 'right',
                                                        },
                                                    }}
                                                    type="number"
                                                />
                                            </div>
                                        </li>
                                        <li className="text-left flex-1 mr-2 text-3xl lg:text-4xl  font-bold py-4 rounded-full">
                                            <Button className="rounded-full" size="large" variant="contained" onClick={handleButtonClickCarica} style={{ borderRadius: '9999px' }}>Carica Foglietto</Button>
                                        </li>
                                    </ul>
                                </div>
                            </header>
                        ) : null}

                        {phase !== 'caricato' && phase !== 'modificaquantita' && phase !== 'invio_in_corso' ? (
                            <header className="header_cucine_inf">
                                <div className="z-0 xl:text-3xl font-extralight xl:text-end lg:text-3xl lg:py-2 lg:text-center">
                                    {showAlternateView ? (
                                        <p className="flex items-center justify-center">
                                            <Button size="large" color="secondary" className="font-semibold rounded-full" variant="outlined" style={{ borderRadius: '9999px' }} onClick={handleButtonClickCaricaConto1}>Camerieri</Button>
                                            <IconButton 
                                                onClick={caricaStatistiche} 
                                                color={!isAuthorizedUser ? "default" : "primary"}
                                                disabled={!isAuthorizedUser}
                                                sx={{ ml: 1, border: '1px solid', padding: '10px', opacity: !isAuthorizedUser ? 0.4 : 1 }}
                                            >
                                                <StarsIcon fontSize="large" />
                                            </IconButton>

                                        </p>
                                    ) : (
                                        <div className="flex items-center justify-end">
                                            <ButtonGroup sx={{ display: { xs: 'none', sm: 'block' } }}>
                                                {lastLog.map((row) => (
                                                    <span key={row.foglietto}>
                                                        <Button size="large" className="rounded-full text-xl" variant="contained" style={{ borderRadius: '9999px' }} onClick={() => { carica(row.foglietto) }} startIcon={<Filter1Icon />} >{row.foglietto}</Button>
                                                        &nbsp;&nbsp;
                                                    </span>
                                                ))}
                                                <Button size="large" color="secondary" className="font-semibold rounded-full" variant="outlined" style={{ borderRadius: '9999px' }} onClick={handleButtonClickCaricaConto1}>Camerieri</Button>
                                            </ButtonGroup>
                                            <IconButton 
                                                onClick={caricaStatistiche} 
                                                color={!isAuthorizedUser ? "default" : "primary"}
                                                disabled={!isAuthorizedUser}
                                                sx={{ ml: 2, border: '2px solid', bgcolor: 'white', opacity: !isAuthorizedUser ? 0.4 : 1 }}
                                            >
                                                <StarsIcon fontSize="large" />
                                            </IconButton>
                                             <ButtonGroup sx={{ display: { xs: 'block', sm: 'none' } }}>
                                                {lastLog.map((row) => (
                                                    <span key={row.foglietto}>
                                                        <Button size="small" className="rounded-full text-xl" variant="contained" style={{ borderRadius: '9999px' }} onClick={() => { carica(row.foglietto) }} startIcon={<Filter1Icon />} >{row.foglietto}</Button>
                                                        &nbsp;&nbsp;
                                                    </span>
                                                ))}
                                                <Button size="small" color="secondary" className="font-semibold rounded-full" variant="outlined" style={{ borderRadius: '9999px' }} onClick={handleButtonClickCaricaConto1}>Camerieri</Button>
                                             </ButtonGroup>
                                        </div>
                                    )}
                                </div>
                            </header>
                        ) : (
                            // Mostriamo i dettagli del conto solo se siamo in modalità "caricato" e non durante il loader di invio
                            phase === 'caricato' && (
                                <div className="flex justify-between items-center w-full">
                                    <div className="flex space-x-8">
                                        <p className="z-0 text-xl lg:text-3xl font-extralight">
                                            Cameriere: <span className="font-extrabold text-blue-800">{conto?.cameriere}</span>
                                        </p>
                                        <p className="z-0 text-xl lg:text-3xl font-extralight">
                                            Conto: <span className="font-extrabold text-blue-800">{numeroFoglietto}</span>
                                        </p>
                                    </div>
                                </div>
                            )
                        )}

                        <div className="mainContent_cucine_p">{renderPhaseContent()}</div>

                        <footer className="footer_cucine">
                            <div className="flex justify-between items-center w-full">
                                <Button
                                    size="large"
                                    variant="contained"
                                    onClick={handleButtonClickInvia}
                                    disabled={phase !== 'caricato'}
                                    sx={{ padding: '15px 30px', fontSize: '1.5rem', minWidth: '200px' }}
                                    style={{ borderRadius: '9999px' }}
                                >
                                    Invia
                                </Button>
                                <Button
                                    size="large"
                                    variant="contained"
                                    onClick={handleButtonClickAnnulla}
                                    disabled={phase !== 'caricato'}
                                    sx={{ padding: '15px 30px', fontSize: '1.5rem', minWidth: '200px' }}
                                    style={{ borderRadius: '9999px' }}
                                >
                                    Annulla
                                </Button>
                            </div>
                        </footer>
                    </div>

                    <Modal open={openPopup} onClose={handleClosePopup} aria-labelledby="modal-stats-title">
                        <Box sx={{ ...styleModal, p: 2, width: '90%', maxWidth: '450px', height: 'auto', maxHeight: '90vh', display: 'flex', flexDirection: 'column', borderRadius: '12px', overflow: 'hidden' }}>
                            <Typography id="modal-stats-title" variant="h6" color="primary" sx={{ mb: 1, fontWeight: 'bold', fontSize: '1.1rem', flexShrink: 0 }}>
                                Statistiche: {nomeCucina}
                            </Typography>
                            <Box sx={{ mb: 1.5, p: 1, bgcolor: '#f0f7ff', borderRadius: '8px', border: '1px solid #d0e3ff', flexShrink: 0 }}>
                                <Typography variant="body1" sx={{ lineHeight: 1.2, fontWeight: 'medium' }}>
                                    Stima coperti da servire: <b className="text-blue-700" style={{ fontSize: '1.3rem', marginLeft: '4px' }}>{copertiInAttesa}</b>
                                </Typography>
                                <Typography variant="caption" sx={{ color: '#555', display: 'block', mt: 0.5 }}>
                                ({dettaglioCoperti.seduti} + {dettaglioCoperti.nonseduti_incoda}) - {dettaglioCoperti.serviti } = (tot.seduti + in coda) - tot.serviti
                                </Typography>
                            </Box>
                            <Typography variant="caption" sx={{ mb: 0.5, textTransform: 'uppercase', fontSize: '0.65rem', color: 'gray', fontWeight: 'bold', display: 'block', flexShrink: 0 }}>
                                Previsione piatti
                            </Typography>
                            <Box sx={{ border: '1px solid #eee', borderRadius: '4px', flexGrow: 0, height: 'auto', maxHeight: '40vh', overflowY: 'auto' }}>
                                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                                    <thead style={{ position: 'sticky', top: 0, zIndex: 1, backgroundColor: '#f8f9fa' }}>
                                        <tr style={{ borderBottom: '2px solid #1976d2' }}>
                                            <th style={{ textAlign: 'left', padding: '6px 10px' }}>Piatto</th>
                                            <th style={{ textAlign: 'right', padding: '6px 10px' }}>Calcolo</th>
                                            <th style={{ textAlign: 'right', padding: '6px 10px' }}>Stima</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {menuPrevisionale.map((item) => {
                                            const percentualeDecimale = item.percentuale / 100;
                                            const quantitaPrevista = Math.ceil(copertiInAttesa * percentualeDecimale);
                                            return (
                                                <tr key={item.id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                                                    <td style={{ padding: '4px 10px' }}>
                                                        <div style={{ fontWeight: 'bold', color: '#333' }}>{item.piatto}</div>
                                                        <div style={{ fontSize: '0.65rem', color: '#888' }}>{item.percentuale}%</div>
                                                    </td>
                                                    <td style={{ textAlign: 'right', padding: '4px 10px', color: '#666', fontSize: '0.75rem' }}>
                                                        {copertiInAttesa}×{percentualeDecimale.toFixed(2)}
                                                    </td>
                                                    <td style={{ textAlign: 'right', padding: '4px 10px' }}>
                                                        <b style={{ fontSize: '1.05rem', color: '#1976d2' }}>{quantitaPrevista}</b>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </Box>
                            <Box sx={{ mt: 1.5, display: 'flex', justifyContent: 'center', flexShrink: 0 }}>
                                <Button variant="contained" onClick={handleClosePopup} size="small" sx={{ borderRadius: '20px', px: 4, textTransform: 'none' }}>
                                    Chiudi
                                </Button>
                            </Box>
                        </Box>
                    </Modal>

                    <Snackbar
                        open={openSnackbar}
                        autoHideDuration={6001}
                        onClose={handleClose}
                        message={snackbarMessage} // <-- ORA LEGGE IL MESSAGGIO SALVA
                    />
                    <Snackbar

                    />
                </main>
            );
        }
    } else {
        return (
            <main>
                <div className="flex flex-wrap flex-col">
                    <div className='text-center '>
                        <div className="p-4 mb-4 text-xl text-red-800 rounded-lg bg-red-50" role="alert">
                            <span className="text-xl font-semibold">Accesso Negato (CUCINA): {session?.user?.name}</span>
                        </div>
                    </div>
                </div>
            </main>
        );
    }
}