'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession } from 'next-auth/react';
import clsx from 'clsx';

// IMPORT ICONE
import HomeIcon from '@mui/icons-material/Home';
import CakeIcon from '@mui/icons-material/Cake';
import LocalDrinkIcon from '@mui/icons-material/LocalDrink';
import SportsBarIcon from '@mui/icons-material/SportsBar';
import DinnerDiningIcon from '@mui/icons-material/DinnerDining';
import RestaurantOutlinedIcon from '@mui/icons-material/RestaurantOutlined';
import KebabDiningOutlinedIcon from '@mui/icons-material/KebabDiningOutlined';

export default function DashboardLinksBocche() {
  const pathname = usePathname();
  const { data: session } = useSession();

  const links = [
    { name: 'Home', href: '/dashboard', icon: HomeIcon },
    { name: 'Antipasti', href: '/dashboard/antipasti', icon: KebabDiningOutlinedIcon },
    { name: 'Primi', href: '/dashboard/primi', icon: RestaurantOutlinedIcon },
    { name: 'Secondi', href: '/dashboard/secondi', icon: DinnerDiningIcon },
    { name: 'Bevande', href: '/dashboard/bevande', icon: LocalDrinkIcon },
    { name: 'Birre', href: '/dashboard/birre', icon: SportsBarIcon },
    { name: 'Dolci', href: '/dashboard/dolci', icon: CakeIcon },
  ];

  return (
    <div className="flex justify-center w-full px-4 py-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 w-full max-w-7xl">
        {links.map((link) => {
          const LinkIcon = link.icon;
          const isActive = pathname === link.href;
          return (
            <Link
              key={link.name}
              href={link.href}
              className={clsx(
                'group flex items-center gap-4 rounded-3xl p-5 transition-all duration-300 border-2 shadow-sm',
                'hover:shadow-xl hover:-translate-y-1 active:scale-95',
                isActive 
                  ? 'bg-orange-50 border-orange-400 text-orange-800' 
                  : 'bg-white border-slate-100 text-slate-700 hover:border-orange-200'
              )}
            >
              <div className={clsx(
                'flex h-14 w-14 items-center justify-center rounded-2xl shrink-0 transition-transform group-hover:rotate-3',
                isActive ? 'bg-orange-600 text-white shadow-lg' : 'bg-slate-100 text-slate-500 group-hover:bg-orange-100 group-hover:text-orange-600'
              )}>
                <LinkIcon className="w-7 h-7" />
              </div>
              <span className="font-black text-lg leading-tight whitespace-normal break-words">
                {link.name}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}